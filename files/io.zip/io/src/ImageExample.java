import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageExample extends JPanel {

	// BufferedImage that stores loaded image
	private BufferedImage bufImage;

	// image and image block widths and heights
	int w, h;

	public ImageExample(String filename) {

		// try to read image into a BufferedImage object
		try {
			bufImage = ImageIO.read(new File(filename));
			w = bufImage.getWidth(null);
			h = bufImage.getHeight(null);
		} catch (IOException e) {
			System.out.println("Image could not be read");
			System.exit(1);
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		// draw the image
		g.drawImage(bufImage,
				0, 0, getWidth(), getHeight(),
				0, 0, w, h,
				null);
	}

	public static void main(String[] args) {

		// load image from the resources directory
		ImageExample img = new ImageExample("resources/sarajevo.jpg");

		JFrame window = new JFrame();
		window.add(img);

		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(800, 485);
		window.setVisible(true);
	}
}
