import javafx.application.Application;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class MP3Play extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {

		final Media media = new Media("file:///path_to_your_mp3_file.mp3");
		final MediaPlayer mediaPlayer = new MediaPlayer(media);
		mediaPlayer.play();

		primaryStage.setTitle("MP3 Audio Player");
		primaryStage.setWidth(200);
		primaryStage.setHeight(200);
		primaryStage.show();
	}
}