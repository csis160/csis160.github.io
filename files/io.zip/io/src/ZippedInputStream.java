import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.util.zip.GZIPOutputStream;
import java.io.PrintStream;

import java.io.IOException;

public class ZippedInputStream {

	public static void main(String[] args) {
				
		try {
			// open input stream and buffer it
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);
			
			// open output, wrap it with GZIP, and then with print stream
			FileOutputStream fos = new FileOutputStream("resources/std-input.txt.gz");
			GZIPOutputStream gzip = new GZIPOutputStream(fos);
			PrintStream ps = new PrintStream(gzip);
			
			// read and print each line (flush output to file every time)
			String line = br.readLine();
			while( line != null ) {
				ps.println(line);
				ps.flush();
				line = br.readLine();
			}
			
			// close input and output streams
			br.close();
			ps.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
