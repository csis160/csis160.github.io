import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;

public class ShuffleImageExample extends JPanel {

	// number of blocks in x and y direction
	private int numBlocks = 4;
	private int numTotalBlocks = numBlocks*numBlocks;
	private int[] blocks;

	// BufferedImage that stores loaded image
	private BufferedImage bufImage;

	// image and image block widths and heights
	int w, h, wBlock, hBlock;

	public ShuffleImageExample(String filename) {

		// try to read image into a BufferedImage object
		try {
			bufImage = ImageIO.read(new File(filename));
			w = bufImage.getWidth(null);
			h = bufImage.getHeight(null);
		} catch (IOException e) {
			System.out.println("Image could not be read");
			System.exit(1);
		}

		wBlock = w/numBlocks;
		hBlock = h/numBlocks;

		// number blocks sequentially from 1 to numTotalBlocks
		blocks = new int[numTotalBlocks];
		for (int i=0; i < numTotalBlocks; i++) {
			blocks[i] = i;
		}
	}

	public void shuffleBlockOrder() {
		// initialize random number generator
		Random randomGen = new Random();			

		// shuffle block order numbers
		for (int i=0; i < blocks.length; i++) {
			int randomPosition = randomGen.nextInt(blocks.length);
			int temp = blocks[i];
			blocks[i] = blocks[randomPosition];
			blocks[randomPosition] = temp;
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		// draw the image block by block in blocks array order
		int dx, dy;
		for (int x=0; x < numBlocks; x++) {
			int sx = x*wBlock;
			for (int y=0; y < numBlocks; y++) {
				int sy = y*hBlock;
				int block = blocks[x*numBlocks+y];
				dx = (block / numBlocks) * wBlock;
				dy = (block % numBlocks) * hBlock;

				// draw each block
				g.drawImage(bufImage,
						dx, dy, dx+wBlock, dy+hBlock,
						sx, sy, sx+wBlock, sy+hBlock,
						null);
			}
		}
	}

	public static void main(String[] args) {

		// load image from the resources directory
		ShuffleImageExample img = new ShuffleImageExample("resources/sarajevo.jpg");
		img.shuffleBlockOrder();

		JFrame window = new JFrame();
		window.add(img);

		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(800, 485);
		window.setVisible(true);
	}
}
