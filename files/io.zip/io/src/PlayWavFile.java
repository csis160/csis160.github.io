import java.io.File;
import javax.swing.JOptionPane;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class PlayWavFile {

	public static void main(String[] args) {
		
		try {
			// open wav file and input audio stream
			File wavFile = new File("resources/path_to_your_wav_file_here.wav");
			AudioInputStream ais = AudioSystem.getAudioInputStream(wavFile);
			
			// create a Clip object and load it with the stream
			Clip clip = AudioSystem.getClip();
			clip.open(ais);
			clip.start();
			
			JOptionPane.showMessageDialog(null, "Playing sound clip, close to exit!");
			
			clip.close();
			ais.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
