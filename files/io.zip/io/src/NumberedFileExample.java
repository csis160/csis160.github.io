import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;

public class NumberedFileExample {

	public static void main(String[] args) {

		// create a dynamic array of strings to keep all file lines
		ArrayList<String> lines = new ArrayList<String>();

		try {
			// open a file reader and wrap it in a buffer
			FileReader fr = new FileReader("resources/input.txt");
			BufferedReader br = new BufferedReader(fr);

			// read line by line and add it to the lines array
			String line = br.readLine();	
			while( line != null ) {
				lines.add(line);
				line = br.readLine();
			}

			// output the lines with the line and total lines number
			for (int i = 0; i < lines.size(); i++) {
				System.out.println((i+1) + "/" + lines.size() + ": " + lines.get(i));
			}			

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
