import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

/** Example of writing and reading a text file */
public class FileIOExample {

	public static void main(String[] args) {
		
		// use a high-level (printing) character-based file output class
		PrintWriter pw = null;
		try {
			// open the file named hello.txt and print strings in it
			pw = new PrintWriter("hello.txt");
			pw.println("hello world");
			pw.println("zdravo svijete");
			
			// close the file (this also flushed the output stream)
			pw.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			// open a file for reading (this is a lower-level class)
			FileReader fileReader = new FileReader("hello.txt");
			
			// input a byte of data each time (read method)
			int input = fileReader.read();
			while( input != -1) {
				// output the inputed byte as a character (cast)
				System.out.print( (char) input );
				input = fileReader.read();
			}
			
			// close the reader at the end to avoid a resource leak
			fileReader.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
}
