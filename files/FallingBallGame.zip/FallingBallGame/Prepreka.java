import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Prepreka {

	protected int x;
	protected int y;
	protected int width;
	
	// public constants
	public static final int MIN_WIDTH = 30;
	public static final int HEIGHT = 15;
	
	public Prepreka(int maxX, int maxY, int maxWidth) {
		
		Random r = new Random();
		
		x = r.nextInt(maxX);
		y = r.nextInt(maxY);
		width = r.nextInt(maxWidth) + MIN_WIDTH;
	}
	
	public void paint(Graphics g) {
		g.setColor(Color.BLACK);
		g.fillRect(x, y, width, HEIGHT);
		
		y -= 2;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}	
	
	public int getWidth() {
		return width;
	}
	
}
