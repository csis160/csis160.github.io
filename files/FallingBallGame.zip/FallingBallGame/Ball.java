import java.awt.Color;
import java.awt.Graphics;

public class Ball {

	// x & y are coordinates of the ball 
	private int x = 200, y = 150;
	private final int size = 30;

	public void paint(Graphics g) {
		g.setColor(Color.BLUE);
		g.fillOval(x,y,size,size);
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
	public void moveX(int deltaX) {
		x += deltaX;
	}

	public void moveY(int deltaY) {
		y += deltaY;
	}	
	
}
