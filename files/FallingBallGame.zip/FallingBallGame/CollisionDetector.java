public class CollisionDetector {
	
	public static boolean collided(Ball b, Prepreka p) {
		
		int ballX = b.getX() + 15;
		int ballY = b.getY() + 30;
		
		if( ballX > p.getX() &&
			ballX < (p.getX() + p.getWidth()) &&
			ballY > p.getY() && 
			ballY < (p.getY() + p.HEIGHT)) {
			
			return true;
			
		}

		return false;	
	}
}
