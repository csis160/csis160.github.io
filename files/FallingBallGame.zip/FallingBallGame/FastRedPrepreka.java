import java.awt.Color;
import java.awt.Graphics;

public class FastRedPrepreka extends Prepreka {

	public FastRedPrepreka(int maxX, int maxY, int maxWidth) {
		super(maxX, maxY, maxWidth);
	}

	@Override
	public void paint(Graphics g) {
		g.setColor(Color.RED);
		g.fillRect(x, y, width, HEIGHT);
		
		y -= 4;
		
	}
}
