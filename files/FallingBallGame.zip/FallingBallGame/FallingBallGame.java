import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class FallingBallGame extends JPanel implements KeyListener, ActionListener {
	
	private Ball ball;
	private Prepreka[] prepreke;
	
	private boolean dead = false;
	private boolean right, left;
	private int velx = 2, vely = 2;
	
	private Color background = Color.WHITE;
	private int windowWidth = 400, windowHeight = 400;
	
	private Timer animationTimer;
	
	public FallingBallGame() {
		
		// start timer
		animationTimer = new Timer(100, this);
		animationTimer.start();
		
		ball = new Ball();
		
		prepreke = new Prepreka[] { 
				new FastRedPrepreka(windowWidth, windowHeight, windowWidth/3),
				new FastRedPrepreka(windowWidth, windowHeight, windowWidth/3),
				new Prepreka(windowWidth, windowHeight, windowWidth/3),
				new Prepreka(windowWidth, windowHeight, windowWidth/3),
				new Prepreka(windowWidth, windowHeight, windowWidth/3), };
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		setBackground(background);
		
		ball.paint(g);
		
		for(Prepreka prepreka : prepreke) {
			prepreka.paint(g);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT){
			// right state code
			right = true;
			left = false;
		}
		else if (e.getKeyCode() == KeyEvent.VK_LEFT){
			// left state code
			right = false;
			left = true;
		}
		else if (e.getKeyCode() == KeyEvent.VK_SPACE){
			// pause the timer
			if(animationTimer.isRunning()) {
				animationTimer.stop();
			}
			else {
				animationTimer.start();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {}

	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void actionPerformed(ActionEvent e) {
		// check if going right or left
		if( right ) {
			ball.moveX( +velx );
		}
		else if( left ) {
			ball.moveX( -velx );
		}
		
		// keep going down
		// ball.moveY( +vely );
		
		for(Prepreka prepreka : prepreke) {
			
			if( CollisionDetector.collided(ball, prepreka)) {
				background = Color.RED;
				dead = true;
				animationTimer.stop();
				break;
			}
		}
		
		repaint();
		
		if( dead ) {
			JOptionPane.showMessageDialog(null, "Game over!");
		}
	}
	
	
	public static void main(String args[]) {
		JFrame window = new JFrame();
		FallingBallGame game = new FallingBallGame();
		window.add(game);
		window.addKeyListener(game);

		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(400, 400);
		window.setVisible(true);
	}
}
