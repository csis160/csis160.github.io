package clocks;
// Binary representation of the Time object.

public class BinaryTime extends Time {

	@Override
	public String toString() {
		
		return Integer.toBinaryString(hour)   + ":" +
			   Integer.toBinaryString(minute) + ":" +
			   Integer.toBinaryString(second);	
	}

}
