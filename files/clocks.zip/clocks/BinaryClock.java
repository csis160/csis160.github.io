package clocks;
import java.awt.Graphics;

public class BinaryClock extends Clock {

	public BinaryClock() {
		t = new BinaryTime();
	}
	
	public void paintComponent( Graphics g ) {
		super.paintComponent(g);
		
		t.now();
       		
		g.drawString(t.toString(), 40, getHeight()/2);	
	}

}