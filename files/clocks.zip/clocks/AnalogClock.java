package clocks;

import java.awt.Color;
import java.awt.Graphics;

// AnalogClock that animates clock hands to show the current time 
public class AnalogClock extends Clock {
	
	private int centerX = 200;
	private int centerY = 200;
	private int handLength = 200;

	
	public AnalogClock() {
		t = new Time();
	}
	
	public void paintComponent( Graphics g ) {
		super.paintComponent(g);

		t.now();
		
		g.setColor(Color.RED);
		g.drawOval(10, 10, 380, 380);
		
		// need angle in radians
		double secAng = 2.0 * Math.PI * t.getSecond() / 60.0;
		double minAng = 2.0 * Math.PI * (t.getMinute() + t.getSecond()/60.0)/60.0;
		double hourAng = 2.0 * Math.PI * (t.getHour() + t.getMinute()/60.0)/12.0;

		int secX = (int)(centerX+Math.sin(secAng)*handLength*0.9);
		int secY = (int)(centerY-Math.cos(secAng)*handLength*0.9);
		
		int minX = (int)(centerX+Math.sin(minAng)*handLength*0.9);
		int minY = (int)(centerY-Math.cos(minAng)*handLength*0.9);
		
		int hourX = (int)(centerX+Math.sin(hourAng)*handLength*0.5);
		int hourY = (int)(centerY-Math.cos(hourAng)*handLength*0.5);

		g.setColor(Color.LIGHT_GRAY);
		g.drawLine(centerX, centerY, secX, secY);
		
		g.setColor(Color.YELLOW);
		g.drawLine(centerX, centerY, minX, minY);
		
		g.setColor(Color.BLUE);
		g.drawLine(centerX, centerY, hourX, hourY);
		
	}

}