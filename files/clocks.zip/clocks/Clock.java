package clocks;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;


// main Clock class that extends JPanel and setups up painting canvas
// Clock class contains our Time class, plus Timer for animation 

public class Clock extends JPanel implements ActionListener {

	protected Time t;
	private Timer animationTimer;

	// initialize timers in the clock
	public Clock() {
		// schedule timer updates (period number in milliseconds)
		animationTimer = new Timer(1000, this);
		animationTimer.start();
	}

	public void paintComponent( Graphics g ) {
		super.paintComponent(g);
		setBackground(Color.BLACK);

		Font font = new Font("Lucida Grande", Font.PLAIN, 32);
		g.setFont(font);
		g.setColor(Color.RED);        
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		repaint();
	}
}
