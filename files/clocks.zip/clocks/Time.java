package clocks;
import java.util.Calendar;

// Time class holds current time instance refreshed by update method

public class Time {

	// private instance variables
	protected int hour   = 0;
	protected int minute = 0;
	protected int second = 0;

	// constructor that updates the current time
	public Time() {
		now();
	}
	
	// public getters
	public int getHour() {
		return hour;
	}
	
	public int getMinute() {
		return minute;
	}
	
	public int getSecond() {
		return second;
	}
	
	// now function gets the current time using java.util.Calendar class
	public void now() {
		
		Calendar cal = Calendar.getInstance();

		hour = cal.get(Calendar.HOUR_OF_DAY);
		minute = cal.get(Calendar.MINUTE);
		second = cal.get(Calendar.SECOND);
	}

	// output string representation of the Time object
	public String toString() {
		return String.format( "Time object (%d, %d, %d)", hour, minute, second );
	}

}
