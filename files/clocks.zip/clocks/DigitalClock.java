package clocks;
import java.awt.Color;
import java.awt.Graphics;

public class DigitalClock extends Clock {

	public DigitalClock() {
		t = new Time();
	}
	
	public void paintComponent( Graphics g ) {
		super.paintComponent(g);
		
		t.now();
       	
		// simple digital clock
		// g.drawString(now.toString(), getWidth()/2-80, getHeight()/2);
		
		// clock that randomly moves up/down seconds, minutes, and hours 
		g.drawString(""+ t.getHour(), getWidth()/2-80, getHeight()/2 + (int)(Math.random()*20));

		g.setColor(Color.YELLOW);
		g.drawString(""+ t.getMinute(), getWidth()/2-40, getHeight()/2 + (int)(Math.random()*20));

		g.setColor(Color.GREEN);
		g.drawString(""+ t.getSecond(), getWidth()/2 , getHeight()/2 + (int)(Math.random()*20));
		
	}

}