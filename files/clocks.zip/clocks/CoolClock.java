package clocks;
import java.awt.Color;
import java.awt.Graphics;

public class CoolClock extends Clock {

	public CoolClock() {
		t = new Time();
	}
	
	@Override
	public void paintComponent( Graphics g ) {
		super.paintComponent(g);

		t.now();
		
		g.setColor(Color.BLACK);
		g.drawOval(10, 10, 380, 380);
		
		// need angle in degrees
		int secAng = (int) (360 * t.getSecond() / 60.0);
		int minAng = (int) (360 * (t.getMinute() + t.getSecond()/60.0) / 60.0);
		int hourAng = (int) (360 * (t.getHour()%12 + t.getMinute()/60.0) / 12.0);

		g.setColor(Color.GREEN);
		g.fillArc(11, 11, 378, 378, 90, -secAng);
		g.setColor(Color.WHITE);
		g.fillArc(20, 20, 360, 360, 0, 360);

		g.setColor(Color.YELLOW);
		g.fillArc(20, 20, 360, 360, 90, -minAng);
		g.setColor(Color.WHITE);
		g.fillArc(30, 30, 340, 340, 0, 360);
		
		g.setColor(Color.RED);
		g.fillArc(30, 30, 340, 340, 90, -hourAng);
		g.setColor(Color.WHITE);
		g.fillArc(40, 40, 320, 320, 0, 360);		
	}
	
}
