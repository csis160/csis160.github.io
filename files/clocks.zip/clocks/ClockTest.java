package clocks;

import javax.swing.JFrame;

public class ClockTest {

	public static void main(String args[]) throws InterruptedException {
		
		JFrame window = new JFrame();
		
		// clock instance variable (Clock is a base class)
		// Clock clock;
				
		// AnalogClock clock = new AnalogClock();
		
		// DigitalClock clock = new DigitalClock();
		
		// BinaryClock clock = new BinaryClock();
		
		CoolClock clock = new CoolClock();
		

		// add clock panel to the window
		window.add(clock);
				
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setSize(400, 420);
		window.setVisible(true);
		
	}
	
}
